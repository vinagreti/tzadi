/*!
 * Tzadi Confirm Plugin v1.0
 * Extends TzadiJS Plugin v1.0
 * https://github.com/tzadiinc/tzadi-confirm
 *
 * Copyright 2013 Bruno da Silva Joao
 * Released under the MIT license
 */
TzadiJS.prototype.confirm = function( message, callback ){

   var confirmation = confirm(message);

   if( confirmation && callback )
   	callback();

   return confirmation;

}