/*!
 * Tzadi onkeyupFix Plugin v1.0
 * Extends TzadiJS Plugin v1.0
 * Work around to fix ie7 and 8 onkeyup event
 * Thanks to someone who we do not remember. Sorry!
 */

if (!Array.prototype.filter)

{

  Array.prototype.filter = function(fun /*, thisp */)

  {

    "use strict";

    if (this === void 0 || this === null)

      throw new TypeError();

    var t = Object(this);

    var len = t.length >>> 0;

    if (typeof fun !== "function")

      throw new TypeError();

    var res = [];

    var thisp = arguments[1];

    for (var i = 0; i < len; i++)

    {

      if (i in t)

      {

        var val = t[i]; // in case fun mutates this

        if (fun.call(thisp, val, i, t))

          res.push(val);
      }

    }

    return res;

  };
  
}