<?php
$lang['abt_page_title'] = 'Sobre';
$lang['abt_text1'] = 'Nossa equipe é especializada no desenvolvimento de ferramentas para facilitar o dia-a-dia de agentes e agências.';
$lang['abt_text2'] = '';
$lang['abt_text3'] = 'Como fazemos?';
$lang['abt_text4'] = 'Todos os nossos produtos estão disponíveis através do site TZADI.com.';
$lang['abt_text5'] = '';
$lang['abt_text6'] = '<br>TZADI, a melhor ferramenta de gestão de agências de viagem e intercâmbio!';
$lang["abt_text7"] = "Quem somos?";
$lang["abt_text8"] = "A TZADI é uma empresa de tecnologia voltada para o setor de viagens e intercâmbio.";
$lang["abt_text9"] = "O que fazemos?";