<?php
$lang["fdb_mayWeHelp"] = "Como podemos te ajudar?";
$lang["fdb_email"] = "informe o seu email";
$lang["fdb_subject"] = "informe o assunto";
$lang["fdb_message"] = "mensagem...";
$lang["fdb_send"] = "enviar";
$lang["fdb_cancel"] = "cancelar";
$lang["fdb_pleaseFillSubject"] = "informe o assunto";
$lang["fdb_pleaseFillEmail"] = "informe um e-mail válido";
$lang["fdb_pleaseFillMessage"] = "informe sua mensagem";
$lang["fdb_referer"] = "referência";