<?php
$lang["fdb_mayWeHelp"] = "How can we help you?";
$lang["fdb_email"] = "please enter your email";
$lang["fdb_subject"] = "enter the subject";
$lang["fdb_message"] = "message ...";
$lang["fdb_send"] = "send";
$lang["fdb_cancel"] = "cancel";
$lang["fdb_pleaseFillSubject"] = "enter the subject";
$lang["fdb_pleaseFillEmail"] = "enter a valid email address";
$lang["fdb_pleaseFillMessage"] = "enter your message";
$lang["fdb_referer"] = "reference";