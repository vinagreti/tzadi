<?php
$lang['abt_page_title'] = "About";
$lang['abt_text1'] = 'Our team specializes in the development of tools to facilitate the day-to-day of agents and agencies.';
$lang['abt_text2'] = '';
$lang['abt_text3'] = 'How we do?';
$lang['abt_text4'] = 'All our products are available through the website TZADI.com.';
$lang['abt_text5'] = '';
$lang['abt_text6'] = '<br>TZADI, the best management tool for travel and education exchange agencies!';
$lang["abt_text7"] = "Who we are?";
$lang["abt_text8"] = "The TZADI is formed by former exchange students and professionals in the field of information technology.";
$lang["abt_text9"] = "What we do?";