<h3><?=lang('abt_page_title')?></h3>

<h5><?=lang('abt_text7')?></h5>
<p><?=lang('abt_text8')?></p>

<h5><?=lang('abt_text9')?></h5>
<p><?=lang('abt_text1')?></p>
<p><?=lang('abt_text2')?></p>

<h5><?=lang('abt_text3')?></h5>
<p><?=lang('abt_text4')?></p>
<p><?=lang('abt_text5')?></p>
<p><?=lang('abt_text6')?></p>