<h3><?=lang("idx_welcomeToTzadi")?></h3>
<h5><?=lang("idx_unfinishedModuleStudent")?></h5>
<p><?=lang("idx_unfinishedModuleText1")?> <span class="text-success"><strong><a href="<?=base_url()?>blog"><?=ORG_ID.".".ENVIRONMENT?>/blog</a></strong></span></p>
<h5><?=lang("idx_unfinishedModuleText2")?></h5>