<h3><?=lang("usr_Hello")?> <?=$name?>.</h3>
<h4><?=lang("usr_ThanksForFinish")?></h4>
<h4><?=lang("usr_YourTzadiAddressIs")?> <a href="http://<?=$org_id?>.tzadi.com"><?=$org_id?>.tzadi.com</a></h4>
<h4><?=lang("usr_AddressAdvantage")?></h4>
<p><small><?=lang("usr_signupMailTxt8")?> <a href="http://tzadi.com/contact"><?=lang("usr_signupMailTxt9")?></a>.</small></p>