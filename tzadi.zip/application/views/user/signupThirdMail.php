<h3><?=lang("usr_signupMailTxt1")?> <?=$name?>.</h3>
<h4><?=lang("usr_signupMailTxt2")?></h4>
<h4><?=lang("usr_signupThirdMailText1")?> <?=$registerFrom?> <?=lang("usr_signupThirdMailText2")?></h4>
<p><?=lang("usr_signupMailTxt4")?> <?=$email?></p>
<p><?=lang("usr_signupMailTxt5")?> <?=$password?></p>
<h4><?=lang("usr_signupThirdMailText3")?> <?=$registerFrom?>, <?=lang("usr_signupThirdMailText4")?></h4>
<p><?=lang("usr_signupMailTxt6")?> <small><?=lang("usr_signupMailTxt7")?></small></p>
<p><small><?=lang("usr_signupMailTxt8")?> <a href="http://tzadi.com/contact"><?=lang("usr_signupMailTxt9")?></a>.</small></p>