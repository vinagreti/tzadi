<h3><?=lang("usr_signupThirdAddedMailText1")?> <?=$name?>,</h3>
<h4><?=lang("usr_signupThirdAddedMailText2")?> <?=$registerFrom?> <?=lang("usr_signupThirdAddedMailText3")?></h4>
<p><?=lang("usr_signupMailTxt4")?> <?=$registerFrom?>: <?=$email?></p>
<p><small><?=lang("usr_signupThirdAddedMailText4")?> <?=$registerFrom?> <?=lang("usr_signupThirdAddedMailText5")?></small></p>
<p><small><?=lang("usr_signupThirdAddedMailText6")?> <?=$registerFrom?> <?=lang("usr_signupThirdAddedMailText7")?> <a href="http://tzadi.com/contact"><?=lang("usr_signupMailTxt9")?></a>.</small></p>