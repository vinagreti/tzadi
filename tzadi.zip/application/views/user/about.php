<h3><?=lang('abt_page_title')?></h3>

<?=nl2br($user["about"])?>