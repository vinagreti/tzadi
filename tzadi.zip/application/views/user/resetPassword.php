<h3><?=lang("usr_ResetPassword")?></h3>

<div class="row">
	<div class="span8">
		E-mail
		<div class="control-group">
			<input type="text" id="email" class="input-block-level" />
		</div>
		<a id="resetPassword" class="btn btn-primary"><?=lang("usr_sendNewPassword")?></a>
	</div>
</div>

<div id="usr_validate_mail" class="hide"><?=lang("usr_validate_mail")?></div>