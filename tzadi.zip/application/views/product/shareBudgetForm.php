<div class="modal-header">
  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
  <span class="lead"><?=lang("pdt_shareThisBudget")?></span>
</div>

<div class="modal-body">

  <div class="globalModalAlert hide" id="modalAlert"><?=lang("pdt_fillAllFieldsCorrectly")?></div>

  <div class="row-fluid">
    <div class="span24">
      <label><?=lang("pdt_yourName")?>
        <span class="control-group">
          <input class="mailYourName input-block-level" type="text" value="<?=$this->session->userdata("name")?>" />
        </span>
      </label>
      <label><?=lang("pdt_adressesToSend")?>
        <span class="control-group">
          <input class="mailEmail input-block-level" type="email" />
        </span>
      </label>
      <label><?=lang("pdt_message")?>
        <span class="control-group">
          <textarea class="mailMessage input-block-level" rows="3"></textarea>
        </span>
      </label>
    </div>
  </div>

  <div class="row-fluid">
    <div class="span24">
      <?php foreach( $itens as $iten ) { ?>

          <p><?=$iten["budgetAmount"]?>x <a href="<?=base_url().$iten["_id"]?>" target="_blank"><?=$iten["name"]?></a><span class="pull-right"><?=$iten["humanPrice"]?></span></p>

      <?php } ?>
      <p class="pull-right"><strong class="text-warning"><?=lang("pdt_total")?>:</strong> <?=$price?></p>
    </div>
  </div>

</div>

<div class="modal-footer">
  <a class="shareBudget btn btn-primary"><?=lang("pdt_send")?></a>
  <a class="closeModal btn" data-dismiss="modal"><?=lang("pdt_cancel")?></a>
</div>

<div id="pdt_fillAtLeastOneEmail" class="hide"><?=lang("pdt_fillAtLeastOneEmail")?></div>
<div id="pdt_fillName" class="hide"><?=lang("pdt_fillName")?></div>