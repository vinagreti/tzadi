<div class="row-fluid">
	<div class="span24">
		<h4><?=lang("blg_thereIsNoPosts")?></h4>
	</div>
</div>