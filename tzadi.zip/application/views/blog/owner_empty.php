<div class="row-fluid">
	<div class="span24">
		<h4><?=lang("blg_thereIsNoPosts")?></h4>

		<a class="btn btn-success" href="<?=myOrg_url()?>blog/<?=lang("rt_write")?>"><?=lang("blg_writePost")?></a>
	</div>
</div>