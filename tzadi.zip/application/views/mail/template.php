<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title><?=utf8_decode($subject)?></title>
</head>

<body bgcolor="#8d8e90">
	<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#8d8e90">
		<tr>
			<td>
				<table width="600" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFFF" align="center">
					<tr>
						<td>
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="10%">&nbsp;</td>
									<td width="80%" align="left" valign="top">
										<font style="font-family: Georgia, 'Times New Roman', Times, serif; color:#010101;">

											<?=$message?>

										</font>
									</td>
									<td width="10%">&nbsp;</td>
								</tr>
							</table>
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td align="center"><font style="font-family:'Myriad Pro', Helvetica, Arial, sans-serif; color:#231f20; font-size:8px"><strong>E-mail delivered by <a href= "https://tzadi.com" style="color:#010203; text-decoration:none">TZADI</a></strong></font></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>