<h3><?=lang("tmpt_permission_denied")?> <a href="<?=base_url()?>contact"><?=lang("tmpt_contact_us")?></a>.</h3>

<a class="btn btn-success" href="<?=base_url()?>user"><?=lang("tmpt_Login")?></a>