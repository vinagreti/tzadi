<h3><?=lang("idx_Helo")?> <?=$this->session->userdata("name")?></h3>
<h4><?=lang("idx_fromNowYouHaveIdentity")?></h4>
<p><?=lang("idx_whyWontCreateThe")?> <a href="<?=base_url().lang("rt_products")?>"><?=lang("idx_productsAndServices")?></a> <?=lang("idx_thatYouWorkWith")?>?</p>
<p><?=lang("idx_notForgetToRegister")?> <a href="<?=base_url().lang("rt_customer")?>"><?=lang("idx_customers")?></a> & <a href="<?=base_url().lang("rt_supplier")?>"><?=lang("idx_suppliers")?></a>.</p>
<p><?=lang("idx_AllOptionCanBeFoundInAgency")?>.</p>
<p><?=lang("idx_YouCanAlsoShareYourExperiencsThrough1")?> <a href="<?=base_url()?>blog">blog</a> <?=lang("idx_YouCanAlsoShareYourExperiencsThrough2")?></p>
<h5><?=lang("idx_YourTzadiAddressIs")?>: <span class="text-success"><strong><?=base_url()?></strong></span>. <?=lang("idx_giveToCustomerAndClientAccess")?>.</h5>
<p><?=lang("idx_title")?></p>